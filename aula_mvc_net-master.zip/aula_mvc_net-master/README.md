# aula_mvc_net


### Zipando o projeto para enviar no moodle
```bash
git archive --format zip -o MeuNome_TP0.zip master
```
